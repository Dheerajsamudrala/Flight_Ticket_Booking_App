package com.flightbooking.app.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flightbooking.app.beans.AdminUserBean;
import com.flightbooking.app.dao.AdminUserDao;
import com.flightbooking.app.dao.impl.AdminUserDaoImpl;

@SuppressWarnings("serial")
@WebServlet("/admin/signup")
public class AdminSignUpServlet extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		AdminUserBean adminBean = new AdminUserBean();
		AdminUserDao adminUserDao = new AdminUserDaoImpl();

		adminBean.setAdminname(req.getParameter("username"));
		adminBean.setAdminpassword(req.getParameter("upassword"));
		adminBean.setAdminfname(req.getParameter("firstname"));
		adminBean.setAdminlastname(req.getParameter("lastname"));
		adminBean.setAdmingender(req.getParameter("gender"));
		adminBean.setAdminaddress(req.getParameter("address"));
		adminBean.setAdminemail(req.getParameter("email"));
		adminBean.setAdminphonenum(Long.parseLong(req.getParameter("phonenumber")));

		int row = adminUserDao.createAdminUser(adminBean);

		resp.setContentType("text/html");
		PrintWriter pw = resp.getWriter();
		if (row > 0) {
			pw.print("Admin Created Succesfully");
			RequestDispatcher rd = req.getRequestDispatcher("/WelcomeAdmin.html");
			rd.include(req, resp);

		} else {
			pw.print("Error occured while creating user");
		}

	}

}
