package com.flightbooking.app.beans;

import java.io.Serializable;
import java.time.LocalDateTime;

@SuppressWarnings("serial")
public class FlightBean implements Serializable {

	int flightId;
	String flightName;
	String source;
	String destination;
	String flightStatus;
	LocalDateTime sourceTime;
	LocalDateTime destinationTime;
	int capacity;
	
	public int getFlightId() {
		return flightId;
	}
	public void setFlightId(int flightId) {
		this.flightId = flightId;
	}
	public String getFlightName() {
		return flightName;
	}
	public void setFlightName(String flightName) {
		this.flightName = flightName;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public String getFlightStatus() {
		return flightStatus;
	}
	public void setFlightStatus(String flightStatus) {
		this.flightStatus = flightStatus;
	}
	public LocalDateTime getSourceTime() {
		return sourceTime;
	}
	public void setSourceTime(LocalDateTime sourceTime) {
		this.sourceTime = sourceTime;
	}
	public LocalDateTime getDestinationTime() {
		return destinationTime;
	}
	public void setDestinationTime(LocalDateTime destinationTime) {
		this.destinationTime = destinationTime;
	}
	
}
