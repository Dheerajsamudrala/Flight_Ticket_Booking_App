package com.flightbooking.app.dao;

import com.flightbooking.app.beans.AdminUserBean;

public interface AdminUserDao {

	int createAdminUser(AdminUserBean abean);

	AdminUserBean fetchAdminUser(AdminUserBean abean);

	AdminUserBean updateAdminUser(AdminUserBean abean);

	int deletAdminUser(AdminUserBean abean);
}
