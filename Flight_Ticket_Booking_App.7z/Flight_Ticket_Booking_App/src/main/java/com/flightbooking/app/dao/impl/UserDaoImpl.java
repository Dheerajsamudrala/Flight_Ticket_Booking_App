package com.flightbooking.app.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.flightbooking.app.beans.UserBean;
import com.flightbooking.app.dao.UserDao;
import com.flightbooking.app.db.DBConnector;

public class UserDaoImpl implements UserDao {

	@Override
	public int createUser(UserBean ubean) {

		int row = 0;
		Connection conn = DBConnector.getConnection();
		if (null != conn) {
			try (PreparedStatement pst = conn.prepareStatement(
					"insert into USER_REG(username, upassword, fname, lastname, gender, phonenum, address, email) values(?,?,?,?,?,?,?,?)")) {
				pst.setString(1, ubean.getUsername());
				pst.setString(2, ubean.getUpassword());
				pst.setString(3, ubean.getFname());
				pst.setString(4, ubean.getLastname());
				pst.setString(5, ubean.getGender());
				pst.setLong(6, ubean.getPhonenum());
				pst.setString(7, ubean.getAddress());
				pst.setString(8, ubean.getEmail());
				row = pst.executeUpdate();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return row;
	}

	@Override
	public UserBean fetchUser(UserBean ubean) {
		UserBean ub = null;
		Connection conn = DBConnector.getConnection();
		if (null != conn) {
			try (PreparedStatement pst = conn
					.prepareStatement("select * from USER_REG where username =? and upassword = ?")) {

				pst.setString(1, ubean.getUsername());
				pst.setString(2, ubean.getUpassword());
				ResultSet rs = pst.executeQuery();
				while (rs.next()) {
					ub = new UserBean();
					ub.setUserid(rs.getInt(1));
					ub.setUsername(rs.getString(2));
					ub.setUpassword(rs.getString(3));
					ub.setFname(rs.getString(4));
					ub.setLastname(rs.getString(5));
					ub.setGender(rs.getString(6));
					ub.setPhonenum(rs.getLong(7));
					ub.setAddress(rs.getString(8));
					ub.setEmail(rs.getString(9));
					ub.setCreate_ts(rs.getTimestamp(10));
					ub.setUpdate_ts(rs.getTimestamp(11));
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return ub;
	}

	@Override
	public UserBean updateUser(UserBean ubean) {

		return null;
	}

	@Override
	public int deletUser(UserBean ubean) {
		int row = 0;
		Connection conn = DBConnector.getConnection();
		if (null != conn) {
			try (PreparedStatement pst = conn
					.prepareStatement("delete from  USER_REG where username =? and upassword = ?")) {
				pst.setString(1, ubean.getUsername());
				pst.setString(2, ubean.getUpassword());
				row = pst.executeUpdate();
			} catch (SQLException e) {

				e.printStackTrace();
			}
		}

		return row;
	}

}
