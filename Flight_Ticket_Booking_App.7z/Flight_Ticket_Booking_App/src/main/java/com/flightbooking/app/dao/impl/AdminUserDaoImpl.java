package com.flightbooking.app.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.flightbooking.app.beans.AdminUserBean;
import com.flightbooking.app.dao.AdminUserDao;
import com.flightbooking.app.db.DBConnector;

public class AdminUserDaoImpl implements AdminUserDao {

	@Override
	public int createAdminUser(AdminUserBean abean) {

		int k = 0;
		Connection conn = DBConnector.getConnection();
		try (PreparedStatement pst = conn.prepareStatement(
				"insert into ADMIN_REG (username, upassword, fname, lastname, gender, phonenum, address, email) values(?,?,?,?,?,?,?,?)");) {
			pst.setString(1, abean.getAdminusername());
			pst.setString(2, abean.getAdminpassword());
			pst.setString(3, abean.getAdminfname());
			pst.setString(4, abean.getAdminlastname());
			pst.setString(5, abean.getAdmingender());
			pst.setLong(6, abean.getAdminphonenum());
			pst.setString(7, abean.getAdminaddress());
			pst.setString(8, abean.getAdminemail());
			k = pst.executeUpdate();

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return k;
	}

	@Override
	public AdminUserBean fetchAdminUser(AdminUserBean abean) {
		AdminUserBean ab = null;
		Connection conn = DBConnector.getConnection();
		if (null != conn) {
			try (PreparedStatement pst = conn
					.prepareStatement("select * from USER_REG where username =? and upassword = ?")) {

				pst.setString(1, abean.getAdminusername());
				pst.setString(2, abean.getAdminpassword());
				ResultSet rs = pst.executeQuery();
				while (rs.next()) {
					ab = new AdminUserBean();
					ab.setAdminid(rs.getInt(1));
					ab.setAdminname(rs.getString(2));
					ab.setAdminpassword(rs.getString(3));
					ab.setAdminfname(rs.getString(4));
					ab.setAdminlastname(rs.getString(5));
					ab.setAdmingender(rs.getString(6));
					ab.setAdminphonenum(rs.getLong(7));
					ab.setAdminaddress(rs.getString(8));
					ab.setAdminemail(rs.getString(9));
					ab.setCreate_ts(rs.getTimestamp(10));
					ab.setUpdate_ts(rs.getTimestamp(11));
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return ab;
	}

	@Override
	public AdminUserBean updateAdminUser(AdminUserBean abean) {

		return null;
	}

	@Override
	public int deletAdminUser(AdminUserBean abean) {
		int row = 0;
		Connection conn = DBConnector.getConnection();
		if (null != conn) {
			try (PreparedStatement pst = conn
					.prepareStatement("delete from  ADMIN_REG where username =? and upassword = ?")) {
				pst.setString(1, abean.getAdminusername());
				pst.setString(2, abean.getAdminpassword());
				row = pst.executeUpdate();
			} catch (SQLException e) {

				e.printStackTrace();
			}
		}

		return row;
	}
}
