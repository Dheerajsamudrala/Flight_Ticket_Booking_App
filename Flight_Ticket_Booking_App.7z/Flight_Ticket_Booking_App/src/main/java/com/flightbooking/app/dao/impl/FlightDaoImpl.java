package com.flightbooking.app.dao.impl;

import com.flightbooking.app.beans.FlightBean;
import com.flightbooking.app.dao.FlightDao;

public class FlightDaoImpl implements FlightDao {

	@Override
	public int addFlight(FlightBean flightBean) {

		return 0;
	}

	@Override
	public FlightBean updateFlightDetails(FlightBean flightBean) {

		return null;
	}

	@Override
	public FlightBean updateFlightStatus(FlightBean flightBean) {

		return null;
	}

	@Override
	public int deleteFlight(FlightBean flightBean) {

		return 0;
	}

}
