package com.flightbooking.app.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnector {

	private static String url = "jdbc:mysql://3.143.223.19:3306/servlet_practice";
	private static String dbuname = "dheerajremote";
	private static String dbpwd = "Dheeraj@123";
	private static Connection conn = null;
	static {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection(url, dbuname, dbpwd);
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	}

	public static synchronized Connection getConnection() {
		return conn;
	}

	private DBConnector() {
	}
}
