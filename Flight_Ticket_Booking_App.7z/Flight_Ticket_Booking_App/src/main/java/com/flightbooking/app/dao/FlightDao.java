package com.flightbooking.app.dao;

import com.flightbooking.app.beans.FlightBean;

public interface FlightDao {

	int addFlight(FlightBean flightBean);

	FlightBean updateFlightDetails(FlightBean flightBean);

	FlightBean updateFlightStatus(FlightBean flightBean);

	int deleteFlight(FlightBean flightBean);

}
