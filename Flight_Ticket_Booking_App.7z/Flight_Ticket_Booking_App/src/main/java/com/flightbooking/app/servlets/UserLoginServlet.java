package com.flightbooking.app.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.flightbooking.app.beans.UserBean;
import com.flightbooking.app.dao.UserDao;
import com.flightbooking.app.dao.impl.UserDaoImpl;

@SuppressWarnings("serial")
@WebServlet("/user/login")
public class UserLoginServlet extends HttpServlet {

	private UserDao userDaoImpl;

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		userDaoImpl = new UserDaoImpl();
		UserBean ub = new UserBean();

		ub.setUsername(req.getParameter("username"));
		ub.setUpassword(req.getParameter("password"));

		UserBean userBean = userDaoImpl.fetchUser(ub);
		resp.setContentType("text/html");
		PrintWriter pw = resp.getWriter();
		RequestDispatcher rd = null;
		if (null != userBean) {
			HttpSession hs = req.getSession();
		    hs.setAttribute("userbean", userBean);
		    hs.invalidate();
			pw.println("====USER Login Details======");
			pw.println("<br>" + "Welcome " + userBean.getFname() + " " + userBean.getLastname() + "</br>");
			rd = req.getRequestDispatcher("WelcomeUser.html");
			rd.include(req, resp);
		} else {
			pw.println("====USER Login failed ======");
			rd = req.getRequestDispatcher("/");
			rd.include(req, resp);
		}

	}

}
