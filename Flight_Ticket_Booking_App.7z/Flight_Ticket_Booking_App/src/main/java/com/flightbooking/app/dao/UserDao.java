package com.flightbooking.app.dao;

import com.flightbooking.app.beans.UserBean;

public interface UserDao {

	int createUser(UserBean ubean);

	UserBean fetchUser(UserBean ubean);

	UserBean updateUser(UserBean ubean);

	int deletUser(UserBean ubean);

}
