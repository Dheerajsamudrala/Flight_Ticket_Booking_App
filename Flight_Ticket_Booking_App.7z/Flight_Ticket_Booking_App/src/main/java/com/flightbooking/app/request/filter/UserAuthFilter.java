package com.flightbooking.app.request.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.flightbooking.app.beans.UserBean;

@WebFilter("/user/*")
public class UserAuthFilter implements Filter {

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {

		HttpServletRequest httpRequest = (HttpServletRequest) request;
		HttpServletResponse httpResponse = (HttpServletResponse) response;
		HttpSession session = httpRequest.getSession(false);

		if (httpRequest.getContextPath().contains("/user/login")) {
			chain.doFilter(httpRequest, httpResponse);
		} else {
			UserBean ubean = session.getAttribute("userbean") != null ? (UserBean) session.getAttribute("userbean")
					: null;
			if (null != ubean) {
				chain.doFilter(httpRequest, httpResponse);
			} else {
				RequestDispatcher rd = httpRequest.getRequestDispatcher("UserLogin.html");
				rd.include(httpRequest, httpResponse);
			}
		}

	}

}
