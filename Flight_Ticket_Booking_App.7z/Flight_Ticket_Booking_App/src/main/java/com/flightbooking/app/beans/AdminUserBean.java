package com.flightbooking.app.beans;

import java.io.Serializable;
import java.sql.Timestamp;

@SuppressWarnings("serial")
public class AdminUserBean implements Serializable{

	private int adminid;
	private String adminusername;
	private String adminpassword;
	private String adminfname;
	private String adminlastname;
	private String admingender;
	private long adminphonenum;
	private String adminaddress;
	private String adminemail;
	private Timestamp create_ts;
	private Timestamp update_ts;
	private String created_by;
	private String updated_by;
	
	public int getAdminid() {
		return adminid;
	}
	public void setAdminid(int adminid) {
		this.adminid = adminid;
	}
	public String getAdminusername() {
		return adminusername;
	}
	public void setAdminname(String adminname) {
		this.adminusername = adminname;
	}
	public String getAdminpassword() {
		return adminpassword;
	}
	public void setAdminpassword(String adminpassword) {
		this.adminpassword = adminpassword;
	}
	public String getAdminfname() {
		return adminfname;
	}
	public void setAdminfname(String adminfname) {
		this.adminfname = adminfname;
	}
	public String getAdminlastname() {
		return adminlastname;
	}
	public void setAdminlastname(String adminlastname) {
		this.adminlastname = adminlastname;
	}
	public String getAdmingender() {
		return admingender;
	}
	public void setAdmingender(String admingender) {
		this.admingender = admingender;
	}
	public long getAdminphonenum() {
		return adminphonenum;
	}
	public void setAdminphonenum(long adminphonenum) {
		this.adminphonenum = adminphonenum;
	}
	public String getAdminaddress() {
		return adminaddress;
	}
	public void setAdminaddress(String adminaddress) {
		this.adminaddress = adminaddress;
	}
	public String getAdminemail() {
		return adminemail;
	}
	public void setAdminemail(String adminemail) {
		this.adminemail = adminemail;
	}
	public Timestamp getCreate_ts() {
		return create_ts;
	}
	public void setCreate_ts(Timestamp create_ts) {
		this.create_ts = create_ts;
	}
	public Timestamp getUpdate_ts() {
		return update_ts;
	}
	public void setUpdate_ts(Timestamp update_ts) {
		this.update_ts = update_ts;
	}
	public String getCreated_by() {
		return created_by;
	}
	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}
	public String getUpdated_by() {
		return updated_by;
	}
	public void setUpdated_by(String updated_by) {
		this.updated_by = updated_by;
	}
	
	
	
	
}
